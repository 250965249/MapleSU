/*
 * Copyright 2023 John "topjohnwu" Wu
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.topjohnwu.superuser.internal;

import androidx.annotation.RestrictTo;

import com.topjohnwu.superuser.io.SuFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public final class IOFactory {

    static final byte[] JUNK = new byte[1];

    private IOFactory() {}

    public static ShellIO shellIO(SuFile file, String mode) throws FileNotFoundException {
        switch (mode) {
            case "r":
                break;
            case "rw":
            case "rws":
            case "rwd":
                mode = "rw";
                break;
            default:
                throw new IllegalArgumentException("Unknown mode: " + mode);
        }
        return ShellIO.get(file, mode);
    }

    public static RAFWrapper raf(File file, String mode) throws FileNotFoundException {
        return new RAFWrapper(file, mode);
    }

    public static InputStream fifoIn(SuFile file) throws FileNotFoundException {
        return ShellPipeStream.openReadStream(file);
    }

    public static OutputStream fifoOut(SuFile file, boolean append)
            throws FileNotFoundException {
        return ShellPipeStream.openWriteStream(file, append);
    }
}
